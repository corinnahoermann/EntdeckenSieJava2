public class ComputerRun {
    public static void main(String[] args) {
		Laptop lt1 = new Laptop("192.168.0.1",3,512,15);
        Laptop lt2 = new Laptop("192.168.0.2",4,128,17);
		Computer c1 = new Computer("192.168.0.3",3,512);
		Computer c2 = new Computer("192.168.0.4",3,1024);
		
		lt1.charge(45);
		System.out.println(lt1.getBatteryLevel());
		lt2.fullyCharge();
		System.out.println(lt2.getBatteryLevel());
	}       
    
}