public class Laptop implements Chargeable {
   private int batteryLevel;
   private int screenSize;

   public Laptop(int screenSize) {
       this.batteryLevel = 0;
       this.screenSize = screenSize;
   }

    public int getScreenSize() {
        return screenSize;
    }

    public void fullyCharge() {
        batteryLevel = 100;
   }


   public void charge(int percentage) {
       batteryLevel = percentage;
   }

   public int getBatteryLevel() {
       return batteryLevel;
   }


}
