public interface Chargeable {

    public void fullyCharge();

    public void charge(int percentage);

    public int getBatteryLevel();
}
