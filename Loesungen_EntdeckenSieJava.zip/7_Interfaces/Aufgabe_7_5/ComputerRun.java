public class ComputerRun {
    public static void main(String[] args) {
		Laptop lt1 = new Laptop(15);
        Laptop lt2 = new Laptop(17);
		
		lt1.charge(45);
		System.out.println(lt1.getBatteryLevel());
		lt2.fullyCharge();
		System.out.println(lt2.getBatteryLevel());
	}       
    
}