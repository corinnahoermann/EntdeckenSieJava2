public class CaesarCipher implements Cipher {
    private int key;

    public CaesarCipher(int key) {
        this.key = key;
    }

    public String encrypt(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toUpperCase().toCharArray()) {
            if ('A' <= ch && ch <= 'Z') {
                ch += key;
                if (ch > 'Z') {
                    ch -= 26;
                }
                sb.append(ch);
            }
        }
        return sb.toString();
    }

    public String decrypt(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toUpperCase().toCharArray()) {
            if ('A' <= ch && ch <= 'Z') {
                ch -= key;
                if (ch < 'A') {
                    ch += 26;
                }
                sb.append(ch);
            }
        }
        return sb.toString();
    }
}