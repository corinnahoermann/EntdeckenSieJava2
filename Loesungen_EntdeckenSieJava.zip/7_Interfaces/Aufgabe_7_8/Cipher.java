public interface Cipher {
    public String encrypt(String cleartext);

    public String decrypt(String encryptedtext);
}
