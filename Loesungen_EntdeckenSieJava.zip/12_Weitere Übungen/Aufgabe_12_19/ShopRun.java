public class ShopRun {
    public static void main(String[] args) {
        Article a1 = new Article("USB-Stick", 9.99);
        Article a2 = new Article("Laserdrucker", 478.00);
        Article a3 = new Article("Netzwerkkabel", 7.49);
        Article a4 = new Article("Diskette", 0.19);
        a3.setPrice(6.99);
        System.out.println("Preis geändert: " + a3.getName() + " " + a3.getPrice());
        Customer k1 = new Customer(123, "Karl Musterfrau", 100);
        k1.addArticle(a1);
        k1.addArticle(a3);
        System.out.println("Bestellt: " + a1.getName() + ", " + a3.getName());
        System.out.println("Gesamtpreis=" + k1.calculateTotalPrice());
        boolean paymentOK = k1.payArticles();
        System.out.println("Bezahlt=" + paymentOK);
        System.out.println("Budget=" + k1.getBudget());
        k1.addArticle(a2);
        System.out.println("Bestellt: " + a2.getName());
        paymentOK = k1.payArticles();
        System.out.println("Bezahlt=" + paymentOK);
        System.out.println("Budget=" + k1.getBudget());
    }
}

