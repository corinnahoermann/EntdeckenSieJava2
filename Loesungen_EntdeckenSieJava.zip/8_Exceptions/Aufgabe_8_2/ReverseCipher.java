public class ReverseCipher implements Cipher {
    public ReverseCipher() {
    }

    public String encrypt(String s) throws IllegalArgumentException {

        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("Kein Text vorhanden!");
        }
        return new StringBuilder(s).reverse().toString();
    }

    public String decrypt(String s) throws IllegalArgumentException {

        if (s == null || s.isEmpty()) {
            throw new IllegalArgumentException("Kein Text vorhanden!");
        }
        return encrypt(s);
    }
}