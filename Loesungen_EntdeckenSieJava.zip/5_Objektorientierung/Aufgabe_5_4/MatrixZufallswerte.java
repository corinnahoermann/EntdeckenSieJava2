public static int[][] MatrixZufallswerte(int m, int n, int z) {
    int[][] matrix = new int[n][m];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            matrix[i][j] = (int) (Math.random() * z) + 1;
        }
    }

    return matrix;
}