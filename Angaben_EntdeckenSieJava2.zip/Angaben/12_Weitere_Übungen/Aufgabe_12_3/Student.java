public class Student {

	private String name;
	private boolean awake;

	public Student(String name) {
		this.name = name;
		this.awake = false;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void wakeUp() {
		this.awake = true;
	}
}
