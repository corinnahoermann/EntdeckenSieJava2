public class Studententag {

	public static void main(String[] args) {
		Student object1 = new Student("Jamie");
		Student andy = new Student("Andreas");
		Student randomName = new Student("Naomi");

		object1.wakeUp();
		andy.wakeUp();

		randomName.setName("Melanie");
		System.out.println(randowmName.getName());
  }
}

