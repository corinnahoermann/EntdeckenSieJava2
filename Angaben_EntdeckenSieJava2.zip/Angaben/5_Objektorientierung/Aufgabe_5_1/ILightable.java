public interface Lightable {
    public boolean turnLightsOn();

    public boolean turnLightsOff();
}

