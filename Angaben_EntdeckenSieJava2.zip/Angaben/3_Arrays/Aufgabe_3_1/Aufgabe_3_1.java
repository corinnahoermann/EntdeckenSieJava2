public class Arrays {
	 static Scanner sc = new Scanner(System.in);
 
	 public static void main(String[] args) {
        String[] supermarket = new String[] {"brot","nudel","milch","kaffee","zucker"};
        String lm = "";
	 	
		System.out.println("Bitte Lebensmittel eingeben: ");
        lm = sc.next();
	 	
		int i;

	 	for(i = 0; i < supermarket.length; i++) {

            if(lm.equalsIgnoreCase(supermarket[i])) {

               System.out.println("Lebensmittel ist im Supermarkt lagernd.");

            break;
            }
        }
       
	 	if(i == supermarket.length) {

	 	 	System.out.println("Lebensmittel leider nicht lagernd.");
       }
    }
}


