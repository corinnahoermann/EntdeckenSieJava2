public class NoSeatsAvailableException extends Exception {
    // TODO: Your code here
}
