public class PrisonSimulator {
    public static void main(String[] args) {
        // TODO: Your code here
    }
}