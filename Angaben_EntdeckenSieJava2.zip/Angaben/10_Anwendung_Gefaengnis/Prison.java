public class Prison {
    // TODO: Declare necessary variables and constructors

    public void updateHealthStatus() {
        // TODO: Your code here
    }

    public boolean isSafe() {
        // TODO: Replace method body
        return true;
    }
}