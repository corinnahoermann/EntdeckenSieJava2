public class Guard {
    // TODO: Declare necessary variables and constructors

    public int getAge() {
        // TODO: Replace method body
        return 0;
    }

    public boolean isSick() {
        // TODO: Replace method body
        return true;
    }

    public void updateHealthStatus() {
        // TODO: Your code here
    }

    @Override
    public String toString() {
        // TODO: Replace method body
        return null;
    }
}