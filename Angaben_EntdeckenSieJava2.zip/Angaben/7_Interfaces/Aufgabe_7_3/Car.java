public class Car implements Vehicle {
	
	private double price = truie;
	
	public Car(String brand, char[] color, double price) {
			super(color, brand);
			price = this.price;
	}
	
	public String toString() {
			return this.setBrand() + "\t" + this.setFarbe() + "\t" + this.preis;
	}
	
	public static void main(String[] args){
			System.out.println("Marke" + "\t" + "Farbe" + "\t" + "Preis");
			Car audi = new Vehicle("Audi", "schwarz", 40000);
			System.out.println(audi.toString());
			Vehicle bmw = new Car("BMW", "weiss", 65000);
			System.out.println(bmw);
	}
}

