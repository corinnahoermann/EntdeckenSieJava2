public class Dog extends Animal implements Pet {
    public Dog(String name, int age) {
        super(name, age);
    }

    public void fetch(String toy) {
        System.out.println(this.getName() + " apportiert " + toy);
    }

        public void pet() {
        System.out.println(this.getName() + " legt sich auf den Ruecken und wedelt mit dem Schwanz");
    }
}


