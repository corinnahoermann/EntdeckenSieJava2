public class Cat extends Animal implements Pet {
    private boolean purr;

    public Cat(String name, int age, boolean purr) {
        super(name, age);
        this.purr = purr;
    }

    public boolean isPurring() {
        return purr;
    }

    public void setPurring(boolean purr) {
        this.purr = purr;
    }

 
    public void pet() {
        if (this.purr) {
            System.out.println(this.getName() + " schnurrrrrt");
        } else {
            System.out.println(this.getName() + " faucht und laeuft davon");
        }
    }
}


