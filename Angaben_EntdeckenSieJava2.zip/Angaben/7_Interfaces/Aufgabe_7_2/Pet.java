public interface Pet {
    public void pet();
}

