public interface Movement {
    public void move();
}


