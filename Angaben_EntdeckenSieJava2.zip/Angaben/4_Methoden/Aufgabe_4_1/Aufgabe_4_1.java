public class Unterprogramme {
	static Scanner sc = new Scanner(System.in);
	static String[] supermarket = new String[] {"brot", "nudeln", "kaffee", "milch", "zucker"};
	
	public static void main(String[] args) {
		String lm = "";
		
		System.out.println("Bitte Lebensmittel eingeben: ");
		lm = sc.next();
		
		String result = wortsuche(lm);
		
		System.out.println(result);
	}
	
	public static String wortsuche(String lm) {
		String s = "Lebensmittel ist nicht lagernd.";
		
		for (int i = 0; i < supermarket.length; i++) {
				if (lm.equalsIgnoreCase(supermarket[i])) {
					s = "Lebensmittel ist lagernd.";
					break;
				}
		}
		
		return s;
	}
}


